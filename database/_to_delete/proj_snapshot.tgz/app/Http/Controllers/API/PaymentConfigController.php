<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\PaymentSetting;
use App\Models\PaymentMethod;
use App\Models\BankTransfer;

class PaymentConfigController extends Controller
{
    public function show()
    {
        $s = PaymentSetting::current();
        $active = PaymentMethod::where('is_active', true)->pluck('slug')->all();
        $has = fn ($slug) => in_array($slug, $active, true);

        $squareReady = $has('square') && $s->square_application_id && $s->square_location_id;
        $paypalReady = $has('paypal') && $s->paypal_client_id && $s->paypal_secret;

        // Bank transfer instructions shown in-app when the buyer picks Bank.
        // Non-secret, admin-managed details from the active BankTransfer row.
        $bank = $has('bank_transfer') ? BankTransfer::where('status', 1)->first() : null;

        return response()->json([
            'success' => true,
            'data' => [
                'square' => [
                    'application_id' => $s->square_application_id,
                    'location_id'    => $s->square_location_id,
                    'environment'    => strtolower($s->square_environment ?: 'sandbox'),
                ],
                'paypal' => [
                    'enabled'     => (bool) $paypalReady,
                    'environment' => strtolower($s->paypal_environment ?: 'sandbox'),
                ],
                'methods' => [
                    'card'             => (bool) $squareReady,
                    'apple_pay'        => (bool) $squareReady,
                    'google_pay'       => (bool) $squareReady,
                    'paypal'           => (bool) $paypalReady,
                    'bank_transfer'    => $has('bank_transfer'),
                    'cash_on_delivery' => $has('cash_on_delivery'),
                ],
                'bank' => $bank ? [
                    'account_holder_name' => $bank->account_holder_name,
                    'account_number'      => $bank->account_number,
                    'bank_name'           => $bank->bank_name,
                    'branch_name'         => $bank->branch_name,
                    'note'                => $bank->note,
                ] : null,
            ],
        ]);
    }
}
