<?php

namespace App\Http\Controllers\API\Core;

use App\Http\Controllers\Controller;
use App\Models\Schedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Mail\ScheduleCreatedMail;
use Illuminate\Support\Facades\Mail;
use App\Services\NotificationService;
use App\Notifications\CategoryNotification;
use App\Traits\ApiResponse;
use App\Models\Order;
use App\Models\User;
use Carbon\Carbon;

class ScheduleController extends Controller
{
    use ApiResponse;

    public function index(Request $request)
    {
        try {
            $schedules = Schedule::with(['order.orderItems'])
                ->where('user_id', $request->user()->id)
                ->get()
                ->map(function($schedule) {
                    return [
                        'id' => $schedule->id,
                        'user_id' => $schedule->user_id,
                        'order_id' => $schedule->order_id,
                        'preferred_date' => Carbon::parse($schedule->preferred_date)->format('d/m/Y'),
                        'repeat' => $schedule->repeat,
                        'status' => $schedule->status,
                        'order_number' => $schedule->order->order_number ?? null,
                        'products' => $schedule->order->orderItems->map(function($item) {
                            return [
                                'product_name' => $item->product_name,
                                'quantity' => $item->quantity,
                                'total_price' => $item->subtotal,
                            ];
                        }),
                    ];
                });

            return $this->success($schedules, 'Schedules retrieved successfully.');
        } catch (\Exception $e) {
            return $this->error('Failed to retrieve schedules.', 500);
        }
    }


   public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'order_id' => 'required|exists:orders,id',
            'preferred_date' => 'nullable|date|after_or_equal:today',
            'repeat' => 'boolean',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $order = Order::with('user', 'orderItems')->find($request->order_id);

        if (!$order) {
            return response()->json(['message' => 'Order not found'], 404);
        }


        $schedule = Schedule::create([
            'user_id'        => $order->user_id,
            'order_id'       => $order->id,
        'preferred_date'  => Carbon::createFromFormat('d-m-Y', $request->preferred_date)
                                ->toDateString(),
            'repeat'         => $request->repeat ?? false,
            'status'         => 'active',
        ]);

        $schedule->load('order.orderItems', 'order.user');

        try {
            \Mail::to($order->user->email)
                ->send(new ScheduleCreatedMail($schedule));

            $admins = \App\Models\User::where('is_admin', 1)->pluck('email');

            foreach ($admins as $adminEmail) {
                \Mail::to($adminEmail)
                    ->send(new ScheduleCreatedMail($schedule));
            }

            NotificationService::success(
                $order->user,
                'Order Scheduled',
                "Your order #{$order->order_number} has been scheduled for " . Carbon::parse($schedule->preferred_date)->format('d/m/Y') . "."
            );

            $adminUsers = \App\Models\User::where('is_admin', 1)->get();
            foreach ($adminUsers as $admin) {
                NotificationService::info(
                    $admin,
                    'New Schedule',
                    "Order #{$order->order_number} has been scheduled by {$order->user->name}."
                );
            }
            
            $order->user->notify(new CategoryNotification('transactional', [
                'subject' => 'Order Scheduled',
                'body' => "Your order #{$order->order_number} has been scheduled for " . Carbon::parse($schedule->preferred_date)->format('d/m/Y') . ".",
                'title' => 'Order Scheduled',
                'data' => [
                    'order_id' => $order->id,
                    'schedule_id' => $schedule->id,
                    'type' => 'order_scheduled'
                ]
            ]));

            foreach ($adminUsers as $admin) {
                $admin->notify(new CategoryNotification('transactional', [
                    'subject' => 'New Order Schedule',
                    'body' => "Order #{$order->order_number} has been scheduled by {$order->user->name}.",
                    'title' => 'Order Scheduled',
                    'data' => [
                        'order_id' => $order->id,
                        'schedule_id' => $schedule->id,
                        'type' => 'admin_order_scheduled'
                    ]
                ]));
            }

        } catch (\Exception $e) {
            \Log::error("Schedule email/notification failed: " . $e->getMessage());
        }

        return response()->json([
            'success' => true,
            'message' => 'Schedule created successfully',
            'schedule' => $schedule
        ]);
    }



    public function update(Request $request, $id)
    {
        $schedule = Schedule::where('user_id', $request->user()->id)->findOrFail($id);


        if ($request->has('repeat')) {
            $request->merge([
                'repeat' => filter_var($request->repeat, FILTER_VALIDATE_BOOLEAN)
            ]);
        }

        $validator = Validator::make($request->all(), [
            'preferred_date' => 'date|after_or_equal:today',
            'repeat' => 'boolean',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $order = $schedule->order;
        $oldDate = $schedule->preferred_date;
        $newDate = $request->preferred_date;

        $schedule->update($request->only(['preferred_date', 'repeat']));

        if ($request->has('preferred_date') && $order) {
            $order->preferred_delivery_date = $newDate;
            $order->save();

            event(new \App\Events\OrderDeliveryDateUpdated($order, $oldDate, $newDate));
        }

        return response()->json([
            'success' => true,
            'schedule' => $schedule
        ]);
    }

    public function destroy(Request $request, $id)
    {
        $schedule = Schedule::where('user_id', $request->user()->id)->findOrFail($id);
        $schedule->delete();

        return response()->json([
            'success' => true,
            'message' => 'Schedule deleted successfully'
        ]);
    }
}
