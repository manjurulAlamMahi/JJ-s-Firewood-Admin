<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Giveaway;
use App\Models\GiveawayDrawLog;
use App\Models\User;
use App\Models\Entry;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use App\Mail\WinnerMailable;
use App\Services\NotificationService;
use App\Notifications\CategoryNotification;
use App\Notifications\WinnerSelectedNotification;

class DrawGiveawayWinners extends Command
{
    /**
     * The name and signature of the console command.
     */
    protected $signature = 'giveaways:draw-winners';

    /**
     * The console command description.
     */
    protected $description = 'Automatically draw winners for giveaways that are ready';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $now = now();
        $this->info("Checking for giveaways ready to draw... Current server time: " . $now->toDateTimeString());
        
        // Debugging info
        $totalActive = Giveaway::whereIn('status', [Giveaway::STATUS_ACTIVE, '1', 1])->count();
        $totalAutoDraw = Giveaway::where('auto_draw', true)->count();
        $this->info("Active giveaways: {$totalActive} | Auto-draw enabled: {$totalAutoDraw}");

        // Get all giveaways ready to be drawn
        $giveaways = Giveaway::readyToDraw()->get();
        
        if ($giveaways->isEmpty()) {
            $this->info('No giveaways ready to draw at this time.');
            
            // Show why it might be empty
            $potential = Giveaway::whereIn('status', [Giveaway::STATUS_ACTIVE, '1', 1])
                ->where('auto_draw', true)
                ->whereNull('winner_id')
                ->get();
                
            foreach ($potential as $p) {
                $this->line("- Giveaway #{$p->id} ({$p->prize_name}): Draw Date: {$p->draw_date->format('Y-m-d')}, Draw Time: {$p->draw_time}");
            }
            
            return 0;
        }
        
        $this->info("Found {$giveaways->count()} giveaway(s) ready to draw.");
        
        $successCount = 0;
        $failCount = 0;
        
        foreach ($giveaways as $giveaway) {
            try {
                $this->info("Drawing winner for: {$giveaway->prize_name}...");
                
                if ($this->drawWinnerForGiveaway($giveaway)) {
                    $successCount++;
                    $this->info("✓ Winner drawn successfully for: {$giveaway->prize_name}");
                } else {
                    $failCount++;
                    $this->error("✗ Failed to draw winner for: {$giveaway->prize_name}");
                }
                
            } catch (\Exception $e) {
                $failCount++;
                $this->error("✗ Error drawing winner for {$giveaway->prize_name}: {$e->getMessage()}");
                Log::error("Auto-draw failed for giveaway {$giveaway->id}: " . $e->getMessage());
            }
        }
        
        $this->info("\nDrawing complete!");
        $this->info("Success: {$successCount} | Failed: {$failCount}");
        
        if ($successCount > 0) {
            Giveaway::activateNextScheduled();
        }
        
        return 0;
    }
    
    /**
     * Draw winner for a specific giveaway
     */
    private function drawWinnerForGiveaway(Giveaway $giveaway): bool
    {
        try {
            DB::beginTransaction();
            
            // Get all entries with users
            $entries = Entry::where('drawn', false)
                ->where(function ($q) use ($giveaway) {
                    $q->where('giveaway_id', $giveaway->id)
                      ->orWhereNull('giveaway_id');
                })
                ->with('user')
                ->get();
            $totalEntries = $giveaway->totalEntries();
            $totalParticipants = $giveaway->totalParticipants();
            
            if ($totalEntries === 0) {
                $this->warn("No entries found for giveaway #{$giveaway->id} ({$giveaway->prize_name}). Cancelling giveaway.");
                Log::warning("No entries for giveaway {$giveaway->id} - {$giveaway->prize_name}");
                
                // Update status but don't set winner
                $giveaway->status = Giveaway::STATUS_CANCELLED;
                $giveaway->save();
                
                DB::commit();
                return false;
            }
            
            $this->info("Total entries (including permanent): {$totalEntries} | Participants: {$totalParticipants}");
            
            // Create weighted array (each user appears as many times as their entry count)
            $weightedEntries = [];
            foreach ($entries as $entry) {
                for ($i = 0; $i < $entry->entry_count; $i++) {
                    $weightedEntries[] = $entry->user_id;
                }
            }
            
            // Randomly select winner
            $winnerUserId = $weightedEntries[array_rand($weightedEntries)];
            $winner = User::find($winnerUserId);
            
            if (!$winner) {
                throw new \Exception("Winner user not found: {$winnerUserId}");
            }
            
            // Update giveaway
            $giveaway->winner_id = $winnerUserId;
            $giveaway->status = Giveaway::STATUS_COMPLETED;
            $giveaway->winner_announced_at = now();
            $giveaway->save();
            
            // ✅ NEW: Mark ALL entries for this giveaway as drawn (consumed)
            // This makes temporary entries "expire" and disappear from the app
            $entriesUpdated = Entry::where('drawn', false)
                ->where(function($q) use ($giveaway) {
                    $q->where('giveaway_id', $giveaway->id)
                      ->orWhere(function($sq) {
                          $sq->whereNull('giveaway_id')
                             ->where('purchase_type', 'paid');
                      });
                })
                ->where('purchase_type', '!=', 'reward')
                ->update([
                    'drawn' => true,
                    'drawn_at' => now()
                ]);
            
            Log::info("Marked {$entriesUpdated} entries as drawn for giveaway {$giveaway->id}");
            
            // Create draw log
            $drawLog = GiveawayDrawLog::createLog(
                $giveaway->id,
                $winnerUserId,
                $totalEntries,
                $totalParticipants,
                true, // Automatic draw
                'Automatically drawn by scheduled task'
            );
            
            // Send notification email
            try {
                $this->sendWinnerNotification($giveaway, $winner);
                $drawLog->notification_sent = true;
                $drawLog->save();
            } catch (\Exception $e) {
                Log::error("Failed to send winner notification for giveaway {$giveaway->id}: {$e->getMessage()}");
                // Don't fail the whole draw just because email failed
            }
            
            DB::commit();
            
            Log::info("Winner automatically drawn for giveaway {$giveaway->id}: User {$winner->id} - {$winner->name}. Marked {$entriesUpdated} entries as consumed.");
            
            // Create Prize record for the winner
            try {
                \App\Models\Prize::create([
                    'user_id' => $winnerUserId,
                    'giveaway_id' => $giveaway->id,
                    'prize_type' => $giveaway->prize_type ?? 'others',
                    'prize_value' => $giveaway->prize_value ?? 0,
                    'won_date' => now(),
                    'status' => 'pending',
                ]);
                Log::info("Prize record created for user {$winnerUserId} for giveaway {$giveaway->id}");
            } catch (\Exception $e) {
                Log::error("Failed to create prize record: " . $e->getMessage());
            }

            return true;
            
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error("Failed to draw winner for giveaway {$giveaway->id}: {$e->getMessage()}");
            throw $e;
        }
    }
    
    /**
     * Send winner notification email
     */
    private function sendWinnerNotification(Giveaway $giveaway, User $winner)
    {
        try {
            // 1. Email to Winner
            Mail::to($winner->email)->send(new WinnerMailable($giveaway, $winner));
            Log::info("Winner email sent to user {$winner->id} for giveaway: {$giveaway->prize_name}");

            // 2. In-app Notification to Winner
            NotificationService::success(
                $winner,
                'Congratulations! 🎁',
                "You have won the giveaway: {$giveaway->prize_name}! Check your prizes to claim it."
            );

            // 3. Notify Admins (Email & In-app)
            $admins = User::where('is_admin', 1)->get();
            foreach ($admins as $admin) {
                // Email to Admin
                Mail::to($admin->email)->send(new WinnerMailable($giveaway, $winner));
                
                // In-app Notification to Admin
                NotificationService::info(
                    $admin,
                    'Giveaway Won',
                    "User {$winner->name} has won the giveaway: {$giveaway->prize_name}."
                );
            }

            // 4. Push Notification to Winner (Transactional)
            $winner->notify(new CategoryNotification('transactional', [
                'subject' => 'Congratulations! You Won!',
                'body' => "You have won the giveaway: {$giveaway->prize_name}! Check your prizes to claim it.",
                'title' => 'Giveaway Won!',
                'data' => [
                    'giveaway_id' => $giveaway->id,
                    'type' => 'giveaway_won'
                ]
            ]));

            // 5. Push Notification to All Users (Broadcast)
            try {
                $users = User::whereNotNull('fcm_token')->where('is_admin', 0)->get();
                
                foreach ($users as $user) {
                    $user->notify(new \App\Notifications\WinnerSelectedNotification($giveaway, $winner));
                }
                Log::info("Winner announced to " . $users->count() . " users (broadcast).");
            } catch (\Exception $e) {
                Log::error("Failed to broadcast winner announcement: " . $e->getMessage());
            }

            Log::info("Comprehensive notifications sent for giveaway: {$giveaway->id}");
        } catch (\Exception $e) {
            Log::error("Failed to send comprehensive notifications: " . $e->getMessage());
        }
    }
}